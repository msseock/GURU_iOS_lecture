//
//  MemoCell.swift
//  Memo
//
//  Created by 석민솔 on 2021/07/05.
//

import UIKit

class MemoCell: UITableViewCell {
    
}
